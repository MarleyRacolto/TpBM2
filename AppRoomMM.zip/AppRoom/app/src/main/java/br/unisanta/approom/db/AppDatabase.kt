package br.unisanta.approom.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import br.unisanta.approom.dao.CourseDao
import br.unisanta.approom.dao.UserDao
import br.unisanta.approom.model.Course
import br.unisanta.approom.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// A anotação @Database informa ao Room que esta classe é o banco de dados principal.
// 'entities' lista todas as classes de dados que se tornarão tabelas no banco.
// 'version' é o número da versão do banco. Deve ser incrementado ao fazer alterações no esquema (schema).
@Database(entities = [User::class, Course::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    // Método abstrato que o Room implementará para fornecer uma instância do UserDao.
    abstract fun userDao(): UserDao
    // Método abstrato que o Room implementará para fornecer uma instância do CourseDao.
    abstract fun courseDao(): CourseDao

    // 'companion object' é semelhante a métodos estáticos em Java.
    // Usado aqui para implementar o padrão Singleton, garantindo que apenas uma instância do banco de dados exista.
    companion object {
        // A anotação @Volatile garante que o valor de INSTANCE seja sempre atualizado e visível para todas as threads.
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Função para obter a instância do banco de dados.
        fun getDatabase(context: Context): AppDatabase {
            // Se a instância já existe, retorna ela.
            // Se não, entra em um bloco sincronizado para criar a instância de forma segura em ambiente multi-thread.
            return INSTANCE ?: synchronized(this) {
                // Cria a instância do banco de dados usando o Room.databaseBuilder.
                val instance = Room.databaseBuilder(
                    context.applicationContext, // Contexto global do aplicativo.
                    AppDatabase::class.java,    // A classe do banco de dados.
                    "app_database"              // O nome do arquivo do banco de dados no dispositivo.
                )
                // Adiciona o callback que será executado na criação do banco de dados para pré-populá-lo.
                .addCallback(AppDatabaseCallback(context.applicationContext))
                .build()
                // Atribui a nova instância à variável INSTANCE.
                INSTANCE = instance
                // Retorna a instância criada.
                instance
            }
        }
    }


    private class AppDatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // Inicia uma coroutine para inserir os dados em uma thread de fundo (background thread).
            // Isso evita travar a interface do usuário durante a operação.
            CoroutineScope(Dispatchers.IO).launch {
                // Usando getDatabase aqui dentro, garantimos que obteremos a instância
                // já criada, de forma segura, sem causar um loop de criação.
                val courseDao = getDatabase(context).courseDao()
                populateCourses(courseDao)
            }
        }


        suspend fun populateCourses(courseDao: CourseDao) {
            // Lista de cursos a serem inseridos.
            val courses = listOf(
                Course(name = "Engenharia mecanica "),
                Course(name = "Sistemas de Informação"),
                Course(name = "Educação física"),
                Course(name = "Comercio exterior"),
                Course(name = "Nutrição"),
                Course(name = "Odontologia")
            )

            // Insere todos os cursos da lista na tabela 'Course'.
            courseDao.insertAll(*courses.toTypedArray())
        }
    }
}
