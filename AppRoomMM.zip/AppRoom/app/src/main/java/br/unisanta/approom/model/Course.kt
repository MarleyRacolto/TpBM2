package br.unisanta.approom.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// A anotação @Entity informa ao Room que esta classe de dados representa uma tabela no banco de dados.
// O parâmetro 'tableName' define o nome da tabela como "courses".
@Entity(tableName = "courses")
// 'data class' é um tipo especial de classe em Kotlin, ideal para armazenar dados.
// Ela gera automaticamente funções úteis como equals(), hashCode(), toString() e copy().
data class Course(
    // A anotação @PrimaryKey marca este campo como a chave primária da tabela.
    // 'autoGenerate = true' faz com que o Room gere automaticamente um ID único para cada novo curso.
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    // Campo para armazenar o nome do curso.
    val name: String
)
