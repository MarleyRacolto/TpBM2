package br.unisanta.approom.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// A anotação @Entity informa ao Room que esta classe de dados representa uma tabela no banco de dados.
// O parâmetro 'tableName' define o nome da tabela como "users".
@Entity(tableName = "users")
// 'data class' é um tipo especial de classe em Kotlin, ideal para armazenar dados.
// Ela gera automaticamente funções úteis como equals(), hashCode(), toString() e copy().
data class User(
    // A anotação @PrimaryKey marca este campo como a chave primária da tabela.
    // 'autoGenerate = true' faz com que o Room gere automaticamente um ID único para cada novo usuário.
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    // Campo para armazenar o nome do usuário.
    val name: String,

    // Campo para armazenar a idade do usuário.
    val age: Int,

    // Campo para armazenar o telefone do usuário.
    val phone: String,

    // Chave estrangeira que liga o usuário ao seu curso. Este ID corresponde à chave primária da tabela 'courses'.
    val courseId: Int,

    // Campo para armazenar a senha do usuário.
    val password: String
)
