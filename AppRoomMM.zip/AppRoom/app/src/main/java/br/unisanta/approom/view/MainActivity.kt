package br.unisanta.approom.view

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import br.unisanta.approom.R
import br.unisanta.approom.databinding.ActivityMainBinding

// MainActivity é a tela principal do aplicativo, exibida após o usuário fazer o login com sucesso.
class MainActivity : AppCompatActivity() {
    // Declaração para o View Binding, que facilita o acesso aos componentes do layout.
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ativa o modo "Edge to Edge", permitindo que o app se estenda por toda a tela, incluindo as áreas das barras de sistema.
        enableEdgeToEdge()
        // Infla (cria) o layout da activity usando o View Binding.
        binding = ActivityMainBinding.inflate(layoutInflater)
        // Define o layout inflado como o conteúdo da tela.
        setContentView(binding.root)

        // Adiciona um listener para ajustar o padding da view principal (R.id.main).
        // Isso garante que o conteúdo da tela não fique escondido atrás das barras de sistema (como a barra de status ou a de navegação).
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            // Obtém as dimensões das barras de sistema.
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Define o padding da view para evitar sobreposição com as barras.
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            // Retorna os insets, completando o processo.
            insets
        }
    }
}
