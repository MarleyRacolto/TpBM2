package br.unisanta.approom.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import br.unisanta.approom.model.Course

// A anotação @Dao informa ao Room que esta é uma interface de Acesso a Dados (Data Access Object).
// É aqui que definimos todas as interações com a tabela 'courses' no banco de dados.
@Dao
interface CourseDao {

    // A anotação @Insert define um método para inserir um novo curso no banco.
    // A palavra-chave 'suspend' indica que esta função deve ser chamada a partir de uma coroutine,
    // garantindo que a operação de banco de dados não trave a interface do usuário.
    @Insert
    suspend fun insert(course: Course)

    // Insere uma lista de cursos no banco de dados.
    // O 'vararg' permite passar um número variável de objetos 'Course'.
    // A estratégia OnConflict.REPLACE garante que, se um curso já existir, ele será substituído.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(vararg courses: Course)

    // A anotação @Query permite definir uma consulta SQL customizada.
    // Esta função seleciona e retorna todos os registros da tabela 'courses'.
    // O resultado é uma lista de objetos 'Course'.
    @Query("SELECT * FROM courses")
    suspend fun getAllCourses(): List<Course>
}
