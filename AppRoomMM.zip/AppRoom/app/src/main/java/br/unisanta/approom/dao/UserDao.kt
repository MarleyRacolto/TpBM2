package br.unisanta.approom.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import br.unisanta.approom.model.User

// A anotação @Dao informa ao Room que esta é uma interface de Acesso a Dados (Data Access Object).
// É aqui que definimos todas as interações com a tabela 'users' no banco de dados.
@Dao
interface UserDao {

    // A anotação @Insert define um método para inserir um novo usuário no banco.
    // A palavra-chave 'suspend' indica que esta função deve ser chamada a partir de uma coroutine ou outra função de suspensão,
    // garantindo que a operação de banco de dados não trave a interface do usuário.
    @Insert
    suspend fun insert(user: User)

    // A anotação @Update define um método para atualizar um usuário existente no banco.
    // O Room utiliza a chave primária (id) do objeto 'user' para encontrar e atualizar a entrada correspondente.
    @Update
    suspend fun update(user: User)

    // A anotação @Query permite definir uma consulta SQL customizada.
    // Esta função busca um usuário específico pelo seu 'id'.
    // O '?' no final de 'User?' indica que o resultado pode ser nulo se nenhum usuário for encontrado com o ID fornecido.
    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Int): User?

    // Esta consulta é usada para a funcionalidade de login.
    // Ela busca por um usuário que tenha o 'name' E a 'password' correspondentes aos parâmetros fornecidos.
    // Retorna o objeto 'User' se a combinação for encontrada, ou nulo caso contrário.
    @Query("SELECT * FROM users WHERE name = :name AND password = :password")
    suspend fun login(name: String, password: String): User?
}
